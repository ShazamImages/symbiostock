<div class="well alert alert-info ">                
    <span class="alignleft"><?php echo symbiostock_directory_link($text = '', false, false) ?></span>
    
    <h3>Extended Network Directory</h3>                   
    
    <p class="text-info">See the <strong><a title="Local Symbiostock author directory" href="<?php echo symbiostock_directory_link($text = '', true) ?>" >directory</a> </strong> page for more sites / authors.</p>
    <div class="clearfix"><br /></div>
</div>